f = open('data.txt')
a = f.read()
f.close()
print a
